import sqlite3

'''
На данном шаге мы подключаем ранее созданную базу данных "chatbot_database.db"
и создаем переменную "cursor" для перемещения по ранее упомянутой базе данных.
'''
conn = sqlite3.connect('mosdosug_database.db', check_same_thread=False)
cursor = conn.cursor()

'''
Теперь создадим функцию, которая будет нужна непосредственно для работы с таблицей.

Создаем переменную "thursday_table" и передаем в нее все данные таблицы "thursday" из "chatbot_database.db" с помощью
запроса 'SELECT * FROM thursday'.

Затем создаем цикл for который автоматически распределяет по переменным соответсвующие элементы кортежа, то есть 
построчно присваивает каждому столбцу значение строки. 

Все эти данные помещаются в переменную "text", которая в итоге представляет собой результат выполнения данной
функции и выводиться в виде таблицы.
'''
def db_cinema_val(name: str, genre: str, age: str, description: str, link:str):
    cursor.execute('INSERT INTO cinema (name, genre, age, description, link) VALUES (?, ?, ?, ?)', (name, genre, age, description, link))
    conn.commit()

def all_films():
    allfilms_table = cursor.execute('SELECT * FROM cinema').fetchall()
    text = []
    for name, genre, age, description, link in allfilms_table:
        text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_films0():
    allfilms0_table = cursor.execute('SELECT * FROM cinema').fetchall()
    text = []
    for name, genre, age, description, link in allfilms0_table:
        if age=='0+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_films6():
    allfilms6_table = cursor.execute('SELECT * FROM cinema').fetchall()
    text = []
    for name, genre, age, description, link in allfilms6_table:
        if age=='6+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_films12():
    allfilms12_table = cursor.execute('SELECT * FROM cinema').fetchall()
    text = []
    for name, genre, age, description, link in allfilms12_table:
        if age=='12+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_films16():
    allfilms16_table = cursor.execute('SELECT * FROM cinema').fetchall()
    text = []
    for name, genre, age, description, link in allfilms16_table:
        if age=='16+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_films18():
    allfilms18_table = cursor.execute('SELECT * FROM cinema').fetchall()
    text = []
    for name, genre, age, description, link in allfilms18_table:
        if age=='18+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def genres():
    filmsgenres_table = cursor.execute('SELECT * FROM cinema').fetchall()
    filmsgenres = []
    for name, genre, age, description, link in filmsgenres_table:
        if genre not in filmsgenres:
            filmsgenres.append(genre)
    return filmsgenres

def cartoon():
    filmsgenres_table = cursor.execute('SELECT * FROM cinema').fetchall()
    cartoons = []
    for name, genre, age, description, link in filmsgenres_table:
        if genre == 'Мультфильм':
            cartoons.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return cartoons
def thriller():
    filmsgenres_table = cursor.execute('SELECT * FROM cinema').fetchall()
    thriller = []
    for name, genre, age, description, link in filmsgenres_table:
        if genre == 'Триллер':
            thriller.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return thriller
def boevik():
    filmsgenres_table = cursor.execute('SELECT * FROM cinema').fetchall()
    boevik = []
    for name, genre, age, description, link in filmsgenres_table:
        if genre == 'Боевик':
            boevik.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return boevik
def comedy():
    filmsgenres_table = cursor.execute('SELECT * FROM cinema').fetchall()
    comedy = []
    for name, genre, age, description, link in filmsgenres_table:
        if genre == 'Комедия':
            comedy.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return comedy
