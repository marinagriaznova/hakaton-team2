import sqlite3

conn = sqlite3.connect('mosdosug_database.db', check_same_thread=False)
cursor = conn.cursor()

def db_concerts_val(name: str, genre: str, age: str, place: str, link: str, date:str, type:str):
    cursor.execute('INSERT INTO concert (name, genre, age, place, link, date, type) VALUES (?, ?, ?, ?)', (name, genre, age, place, link, date, type))
    conn.commit()

def all_concerts():
    allconcerts_table = cursor.execute('SELECT * FROM concert').fetchall()
    text = []
    for name, genre, age, place, link, date, type in allconcerts_table:
        text.append(f"{str(name)}\n{str(genre)}\n{str(age)}\n{str(place)}\n{str(link)}\n")
    return text

def allmusicalconcerts():
    allmusicalconcerts_table = cursor.execute('SELECT * FROM concert').fetchall()
    text = []
    for name, genre, age, place, link, date, type in allmusicalconcerts_table:
        if type=='Музыка':
            text.append(f"{str(name)}\n{str(genre)}\n{str(age)}\n{str(place)}\n{str(link)}\n")
    return text

def allstandupconcerts():
    allstandupconcerts_table = cursor.execute('SELECT * FROM concert').fetchall()
    text = []
    for name, genre, age, place, link, date, type in allstandupconcerts_table:
        if type=='Стендап':
            text.append(f"{str(name)}\n{str(genre)}\n{str(age)}\n{str(place)}\n{str(link)}\n")
    return text