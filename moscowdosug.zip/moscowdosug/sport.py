import sqlite3

conn = sqlite3.connect('mosdosug_database.db', check_same_thread=False)
cursor = conn.cursor()

def db_sport_val(name: str, age: str, link: str, date: str):
    cursor.execute('INSERT INTO cinema (name, age, link, date) VALUES (?, ?, ?, ?)', (name, age, link, date))
    conn.commit()

def all_matches():
    allmatches_table = cursor.execute('SELECT * FROM sport').fetchall()
    text = []
    for name, age, link, date in allmatches_table:
        text.append(f"{str(name)}\n{str(age)}\n{str(link)}\n{str(date)}\n")
    return text
