import sqlite3

conn = sqlite3.connect('mosdosug_database.db', check_same_thread=False)
cursor = conn.cursor()

def db_theatre_val(name: str, genre: str, age: str, description: str, link: str):
    cursor.execute('INSERT INTO theatre (name, genre, age, description, link) VALUES (?, ?, ?, ?)', (name, genre, age, description, link))
    conn.commit()

def all_performances():
    allperformances_table = cursor.execute('SELECT * FROM theatre').fetchall()
    text = []
    for name, genre, age, description, link in allperformances_table:
        text.append(f"{str(name)}\n{str(genre)}\n{str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_performances0():
    allperformances0_table = cursor.execute('SELECT * FROM theatre').fetchall()
    text = []
    for name, genre, age, description, link in allperformances0_table:
        if age=='0+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_performances6():
    allperformances6_table = cursor.execute('SELECT * FROM theatre').fetchall()
    text = []
    for name, genre, age, description, link in allperformances6_table:
        if age=='6+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_performances12():
    allperformances12_table = cursor.execute('SELECT * FROM theatre').fetchall()
    text = []
    for name, genre, age, description, link in allperformances12_table:
        if age=='12+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_performances16():
    allperformances16_table = cursor.execute('SELECT * FROM theatre').fetchall()
    text = []
    for name, genre, age, description, link in allperformances16_table:
        if age=='16+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def all_performances18():
    allperformances18_table = cursor.execute('SELECT * FROM theatre').fetchall()
    text = []
    for name, genre, age, description, link in allperformances18_table:
        if age=='18+':
            text.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return text

def genres():
    performancesgenres_table = cursor.execute('SELECT * FROM theatre').fetchall()
    performancesgenres = []
    for name, genre, age, description, link in performancesgenres_table:
        if genre not in performancesgenres:
            performancesgenres.append(genre)
    return performancesgenres

def drama():
    performancesgenres_table = cursor.execute('SELECT * FROM theatre').fetchall()
    drama = []
    for name, genre, age, description, link in performancesgenres_table:
        if genre == 'Драма':
            drama.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return drama

def musical():
    performancesgenres_table = cursor.execute('SELECT * FROM theatre').fetchall()
    musical = []
    for name, genre, age, description, link in performancesgenres_table:
        if genre == 'Мюзикл':
            musical.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return musical

def ballet():
    performancesgenres_table = cursor.execute('SELECT * FROM theatre').fetchall()
    ballet = []
    for name, genre, age, description, link in performancesgenres_table:
        if genre == 'Балет':
            ballet.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return ballet

def comedy():
    performancesgenres_table = cursor.execute('SELECT * FROM theatre').fetchall()
    comedy = []
    for name, genre, age, description, link in performancesgenres_table:
        if genre == 'Комедия':
            comedy.append(f"{str(name)}\n{str(genre)} {str(age)}\n{str(description)}\n{str(link)}\n")
    return comedy