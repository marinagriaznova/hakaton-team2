import sqlite3

conn = sqlite3.connect('mosdosug_database.db', check_same_thread=False)
cursor = conn.cursor()

def db_puskincard_val(name: str, age: str, description: str, link: str):
    cursor.execute('INSERT INTO cinema (name, age, description, link) VALUES (?, ?, ?, ?)', (name, age, description,link))
    conn.commit()

def all_events():
    allevents_table = cursor.execute('SELECT * FROM pushkincard').fetchall()
    text = []
    for name, age, description,link in allevents_table:
        text.append(f"{str(name)}\n{str(age)}\n{str(description)}\n{str(link)}\n")
    return text